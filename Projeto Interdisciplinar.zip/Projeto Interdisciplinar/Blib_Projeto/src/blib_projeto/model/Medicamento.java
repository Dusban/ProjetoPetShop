/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blib_projeto.model;

/**
 *
 * @author PC 05
 */
public class Medicamento 
{
    private int idMedicamento, validade, dataTratamento;
    private double horaTratamento;
    private String nome, descricao;
    

    public Medicamento()
    {
    idMedicamento = 0;
    validade = 0;
    dataTratamento = 0;
    horaTratamento = 0;
    nome = "";
    descricao = "";
    }


    public int getIdMedicamento() 
    {
        return idMedicamento;
    }
    public void setIdMedicamento(int idMedicamento) {
        this.idMedicamento = idMedicamento;
    }

    
    public int getValidade() 
    {
        return validade;
    }
    public void setValidade(int validade) 
    {
        this.validade = validade;
    }

    
    public int getDataTratamento() 
    {
        return dataTratamento;
    }
    public void setDataTratamento(int dataTratamento) 
    {
        this.dataTratamento = dataTratamento;
    }

    
    public double getHoraTratamento() 
    {
        return horaTratamento;
    }
    public void setHoraTratamento(double horaTratamento) 
    {
        this.horaTratamento = horaTratamento;
    }


    public String getNome() 
    {
        return nome;
    }
    public void setNome(String nome) 
    {
        this.nome = nome;
    }


    public String getDescricao() 
    {
        return descricao;
    }
    public void setDescricao(String descricao) 
    {
        this.descricao = descricao;
    }
}
