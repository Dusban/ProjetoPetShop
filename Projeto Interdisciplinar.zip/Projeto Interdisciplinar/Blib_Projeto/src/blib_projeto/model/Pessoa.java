package blib_projeto.model;


public class Pessoa 
{
    private int idUsuario, idade, cpf, rg;
    private String nome, sexo;
    
    public Pessoa()
    {
    idUsuario = 0;
    idade = 0;
    cpf = 0;
    rg = 0;
    nome = "default";
    sexo = "";
    }

    
    public int getIdUsuario() 
    {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) 
    {
        this.idUsuario = idUsuario;
    }

    
    public int getIdade() 
    {
        return idade;
    }
    public void setIdade(int idade) 
    {
        this.idade = idade;
    }

    
    public int getCpf() 
    {
        return cpf;
    }
    public void setCpf(int cpf) 
    {
        this.cpf = cpf;
    }

    
    public int getRg() 
    {
        return rg;
    }
    public void setRg(int rg) 
    {
        this.rg = rg;
    }

    
    public String getNome() 
    {
        return nome;
    }
    public void setNome(String nome) 
    {
        this.nome = nome;
    }

    
    public String getSexo() 
    {
        return sexo;
    }
    public void setSexo(String sexo) 
    {
        this.sexo = sexo;
    }
}
