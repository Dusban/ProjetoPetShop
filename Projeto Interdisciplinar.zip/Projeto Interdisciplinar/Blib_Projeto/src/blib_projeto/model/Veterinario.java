/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blib_projeto.model;

/**
 *
 * @author PC 05
 */
public class Veterinario 
{
    private int idVeterinario;
    
    
    public Veterinario(){};
    
    
    public int getIdVeterinario() 
    {
        return idVeterinario;
    }
    public void setIdVeterinario(int idVeterinario) 
    {
        this.idVeterinario = idVeterinario;
    }
}
